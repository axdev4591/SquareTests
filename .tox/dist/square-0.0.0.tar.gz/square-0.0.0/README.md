# SquareTests
A starter project to use automated testing in Python

![Tests](https://github.com/axdev4591/SquareTests/actions/workflows/tests.yml/badge.svg)