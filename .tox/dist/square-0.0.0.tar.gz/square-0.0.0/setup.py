#Allows us to install our pakages in editable moe

from setuptools import setup

if __name__ == "__main__":
    setup()